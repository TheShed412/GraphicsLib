** To Compile
Type `make proj3`
`./project3` will run it
