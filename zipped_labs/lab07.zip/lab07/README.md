** To Compile
Type `make lab7`
`./lab7` will run it
