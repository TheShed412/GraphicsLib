** To Compile
Type `make lab1`
`./lab1` will run it