** To Compile
Type `make proj2`
`./project2` will run it
