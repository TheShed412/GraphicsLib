** To Compile
Type `make lab4`
`./lab4` will run it