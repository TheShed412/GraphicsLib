** To Compile
Type `make proj1`
`./project1` will run it
