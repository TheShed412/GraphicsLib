** To Compile
Type `make lab6`
`./lab6` will run it
