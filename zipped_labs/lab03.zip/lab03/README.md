** To Compile
Type `make lab3`
`./lab3` will run it