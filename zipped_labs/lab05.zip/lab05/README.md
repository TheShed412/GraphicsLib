** To Compile
Type `make lab5`
`./lab5` will run it
